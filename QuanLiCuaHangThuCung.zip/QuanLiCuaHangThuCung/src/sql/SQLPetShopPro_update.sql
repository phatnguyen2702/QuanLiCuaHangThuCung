USE ptudpetshop;
GO

/* 1. Trang thai lich hen: Cho xac nhan / Da xac nhan / Hoan thanh / Da huy */
IF COL_LENGTH('LichHen', 'trangThai') IS NULL
    ALTER TABLE LichHen ADD trangThai VARCHAR(20) NOT NULL
        CONSTRAINT DF_LichHen_TrangThai DEFAULT 'Cho xac nhan';
GO

/* 2. Gan thu cung voi chu nuoi (de them khach hang kem thu cung) */
IF COL_LENGTH('ThuCung', 'maKhachHang') IS NULL
    ALTER TABLE ThuCung ADD maKhachHang VARCHAR(10) NULL
        CONSTRAINT FK_ThuCung_KhachHang FOREIGN KEY REFERENCES KhachHang(maKhachHang);
GO

/* 3. Dien chu nuoi cho thu cung da co (lay tu lich hen) */
UPDATE ThuCung
SET maKhachHang = (SELECT TOP 1 l.maKhachHang FROM LichHen l WHERE l.maThuCung = ThuCung.maThuCung)
WHERE maKhachHang IS NULL;
GO

/* 4. (Tuy chon) doi trang thai mau de thay mau tren giao dien */
UPDATE LichHen SET trangThai = 'Da xac nhan' WHERE maLichHen IN ('LH001', 'LH003');
UPDATE LichHen SET trangThai = 'Hoan thanh' WHERE maLichHen = 'LH002';
GO
